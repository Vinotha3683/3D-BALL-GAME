
# Simple Unity 3D Ball Game

A simple 3D Game to **discover Unity 3D**.


## Week 1 :
Manipulating the 3D scene, scripts and components :
<p align="center">
  <img  src="Screenshots/week1.gif" width="500px" >

## Final Game :
<p align="center">
  <img  src="Screenshots/final.gif" width="500px" >
